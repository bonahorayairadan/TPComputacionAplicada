#!/bin/bash

ayuda () {
	echo "Debes colocar el directorio que quieres backupear y el directorio donde quieres que se guarde."
	exit 0
}

if [[ "$1" == "-help" ]]; then
	ayuda
fi

if [[ "$#" -ne 2 ]]; then
	echo "Se requieren dos argumentos: origen y destino."
	ayuda
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error. El directorio de origen `$ORIGEN` no existe."
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error. El directorio de destino `$DESTINO` no existe."
	exit 1
fi

NOMBRE_DIRECTORIO=$(basename "$ORIGEN")
NOMBRE_BACKUP="${NOMBRE_DIRECTORIO}_bkp_${FECHA}.tar.gz"


tar -czf "${DESTINO}/${NOMBRE_BACKUP}" "${ORIGEN}" && cp  "${DESTINO}/${NOMBRE_BACKUP}" "/backup_dir/${NOMBRE_BACKUP}"

if [[ $? -eq 0 ]]; then
	echo "Backup exitoso:$DESTINO/$NOMBRE_BACKUP"
else
	echo "Error al crear el backup."
	exit 1
fi
