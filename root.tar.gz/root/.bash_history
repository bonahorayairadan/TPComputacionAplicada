history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/hostname
cat /etc/hosts
clear
ip a
ipconfig
ip -man
man ip
ip address
clear
ip addr
ls /etc
nano /etc/network
ls /etc/network
clear
ls /etc
ls /etc/network
nano /etc/network/interfaces
cat /etc/network/interfaces
clear
shut down now
shutdown now
ls -la /etc
clean
clear
ls /etc/apt
vi /etc/apt/sources.list
apt clean
apt update
apt upgrade
cat /etc/debian_version
vi /etc/apt/sources.list
apt clean
apt update
apt upgrade
apt clean
apt update
apt full-upgrade
cat /etc/debian_version
clear
ls -la /etc
clear
shutdown now
clear
reboot
clear
setxkbmap latam
clear
ls /etc/apache
clear
nano /etc/apache2
vi /etc/apache2
clear
apt install nano
clear
nano /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
dpkg-reconfigure keyboard-configuration
reboot
whoami
hostname
ls /root
exit
who am i 
whoami
hey
hostname
ls /root
exot
exit
